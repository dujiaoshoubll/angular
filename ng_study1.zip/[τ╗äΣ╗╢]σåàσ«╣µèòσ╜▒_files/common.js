function followCheck(type) {
    $.ajax({
        url: "/m/mazi/follow",
        type: "GET",
        async: false,
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data) {
            if (!data.data.isFollow) {
                $('.order_dialog').fadeIn();
                return false;
            } else {
                return true;
            }
        }
    })
}
function getCookie(name) {
    var strcookie = document.cookie; //获取cookie字符串
    var arrcookie = strcookie.split("; "); //分割
    //遍历匹配
    for (var i = 0; i < arrcookie.length; i++) {
        var arr = arrcookie[i].split("=");
        if (arr[0] == name) {
            return arr[1];
        }
    }
    return "";
}
//ajax
function request(url, async, type, data, callback) {
    $.ajax({
        url: url,
        async: async,
        type: type,
        data: data,
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: callback,
        error: function (e, e2, e3) {}
    })
}
// 绑定手机号
function showTelModal(){
    $('#telModal').modal('show');
}
// 不是编辑器页面则刷新
function closeTelModal(){
    $('#telModal').modal('hide');
}
// chat提交成功,flag表示关闭需要刷新页面
function showSuccModal(flag,url){
    $('#auditSuccessModal').modal('show');
    if(flag){
        $(document).click(function(){
            $(document).off('click')
            if(url){
                window.location.href = url;
            }else{
                window.location.reload();
            }
        })
    }
}
function closeSuccModal() {
    $('#auditSuccessModal').modal('hide');
}
// chat提交失败
function showErrModal() {
    $('#auditWrongModal').modal('show');
}
function closeErrModal() {
    $('#auditWrongModal').modal('hide');
}
// 个人资料提交成功
function mineYes(){
    $('.mine_tip_yes').fadeIn()
    setTimeout(function(){
        $('.mine_tip_yes').fadeOut()
    },2000);
}
// 失败
function mineNo() {
    $('.mine_tip_no').fadeIn()
    setTimeout(function () {
        $('.mine_tip_no').fadeOut()
    }, 2000);
}
// 侧边栏作者推荐关注
$(function(){
    $('body').on('click','.recommend_follow_btn',function(){
        var recommendNode = $(this);
        let requestUrl = encodeURI(window.location.href);
        let followId = recommendNode.attr('author-id');
        let followName = recommendNode.attr('author-name');
        try{
            let followSersorData = {
                author_name:followName,
                author_id:followId
            }
            sensors.track('follow_author',followSersorData);
        }catch(e){}
        if(recommendNode.text()=='关注'){
            $.ajax ({
                url: "/m/v2/mazi/add/follow",
                type: "PUT",
                data: JSON.stringify({followCustomerId:followId,requestUrl:requestUrl}),
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function(data,status){
                    if(data && data.code == 0){
                        recommendNode.addClass("recommend_followed");
                        recommendNode.text('已关注');
                    } else if(data && data.code == -1 && data.message == 'not login' && data.redirectUrl){
                        window.location.href = data.redirectUrl + '?err=' + data.message;
                    } else {
                        //do nothing
                    }
                }
            });
        }else if(recommendNode.text()=='已关注'){
            $.ajax ({
                url: "/m/v2/mazi/cancel/follow",
                type: "PUT",
                data: JSON.stringify({followCustomerId:followId,requestUrl:requestUrl}),
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                success: function(data,status){
                    if(data && data.code == 0){
                        recommendNode.removeClass("recommend_followed");
                        recommendNode.text('关注');
                    } else if(data && data.code == -1 && data.message == 'not login' && data.redirectUrl){
                        window.location.href = data.redirectUrl + '?err=' + data.message;
                    } else {
                        //do nothing
                    }
                }
            });
        }
        return false;
    }) 
})
//上报
function checkSersor(custId){
    try{
        sensors.quick('isReady',function(){
            if(custId != sensors.store.getDistinctId()){
                sensors.login(custId,function(){});
            }
        });
    }catch(e){}
}