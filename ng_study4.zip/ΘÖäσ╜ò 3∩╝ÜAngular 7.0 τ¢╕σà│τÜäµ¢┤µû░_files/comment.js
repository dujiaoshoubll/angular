//import { activity } from "../../../../routes/searchAPI/elasticSearch";

/**
 * Created by wanglei on 2016/12/7.
 */
$(document).ready(function () {
    if(isLogin == 'false' || isLogin == ''){
        $('.comment_view').addClass('login_event')
    }else{
        // 输入框失去焦点
        $('body').on('input propertychange', '.c_mine_input',function(){
            if ($(this).val().length > 0) {
                $(this).addClass('bg_white');
                if ($(this).attr('id')) {
                    // 最顶层评论
                    $(this).parent().next().addClass('no_opacity');
                } else {
                    $(this).next().addClass('no_opacity');
                }
            } else {
                $(this).removeClass('bg_white');
                if ($(this).attr('id')) {
                    // 最顶层评论
                    $(this).parent().next().removeClass('no_opacity');
                } else {
                    $(this).next().removeClass('no_opacity');
                }
            }
        })
        //提交按钮
        $('#submitBtn').click(function () {
            var comment = $('#comment').val();
            var commentId = $('#comments').attr('commentId');
            var length = getWordLength(comment);

            if (length > 500) {
                alert('请不要超过500字哟^_^');
            } else if (comment.length <= 0) {
                alert('评论不能为空哟^_^');
            } else {
                $('#submitBtn').html('正在提交...');
                $('#submitBtn').attr('disabled', true);
                postList(comment, commentId);
            }
        });
        //新评论按钮
        $('body').on('click','.c_send_btn',function () {
            var comment = $('#mineComment').val();
            var commentId = $('#comments').attr('commentId');
            var length = getWordLength(comment);

            if (length > 500) {
                alert('请不要超过500字哟^_^');
            } else if (comment.length <= 0) {
                alert('评论不能为空哟^_^');
            } else {
                postList(comment, commentId,$(this),1);
            }
        });
        //点回复按钮
        $('body').on('click','.reply_view',function(){
            var replyNode = $(this).parent().next();
            if(replyNode.is(':hidden')){
                replyNode.show();
                $(this).children('.c_reply_text').text('取消回复');
            }else{
                replyNode.hide();
                $(this).children('.c_reply_text').text('回复');
            }
        })

    }
    //回复显示
    $('.comment_view').on('mouseenter','.comment_right',function(){
        $(this).find('.c_good').find('.reply_view').show();
    })
    $('.comment_view').on('mouseleave', '.comment_right', function () {
        if ($(this).find('.c_good').find('.reply_view').find('.c_reply_text').text() == '回复') {
            $(this).find('.c_good').find('.reply_view').hide();
        }
    })
    // 展开收起评论
    $('.more_comment').click(function(){
        var commentNode = $(this).parent().children('.comment_inner_view');
        if ($(this).text()=='展开评论'){
            commentNode.show();
            $(this).text('收起评论');
        }else{
            commentNode.hide();
            commentNode.eq(0).show();
            commentNode.eq(1).show();
            $(this).text('展开评论');
        }
    })
    //检测输入字数
    $('#comment').keyup(function () {
        var content = $('#comment').val();
        var length = getWordLength(content);
        var content = length + '/500';
        $('#tip').html(content);
        $('#submitBtn').attr('disabled', false);
        if (length > 500) {
            $('#comment').css('color', 'red');
            $('#tip').css('color', 'red');
            $('#submitBtn').attr('disabled', true);
        } else if (length == 0) {
            $('#submitBtn').attr('disabled', true);
        } else {
            $('#comment').css('color', '');
            $('#tip').css('color', '');
            $('#submitBtn').attr('disabled', false);
        }
    });
    $(".dropload-down").click(function(){
        var that = this;
        $(this).html('<div class="dropload-load">加载中...</div>');
        var startnum = $('#comments').attr('comment-num');
        if(isColumn){
            var bookId = $('#comments').attr('activityid');
            var url = '/m/mazi/columnTopic/comment/' + bookId + "/" + startnum;
        }else{
            var bookId = $('#comments').attr('bookid');
            var url = '/m/mazi/comment/' + bookId + "/" + startnum;
        }
        $.ajax({
            url: url,
            type: 'get',
            dataType: 'json',
            success: function (data, status) {
                if (data.length == 0) {
                    setTimeout(function(){
                        $(that).html('<div class="dropload-noData">到底了...</div>');
                    }, 500);
                } else {
                    var html = insertToHtml(data);
                    $('#comments .comment_content').append(html);
                    var commentNum = $('#comments').attr('comment-num');
                    $('#comments').attr('comment-num', data.length + parseInt(commentNum));
                    $(that).html('<div class="dropload-refresh">查看更多</div>');
                }
            }
        });
    })
    //下拉加载
    // $('.comments').dropload({
    //     scrollArea: window,
    //     domDown : {
    //         domClass   : 'dropload-down',
    //         domRefresh : '<div class="dropload-refresh">查看更多</div>',
    //         domLoad    : '<div class="dropload-load">加载中...</div>',
    //         domNoData: '<div class="dropload-noData">到底了...</div>'
    //     },
    //     loadDownFn: function (me) {
    //         var bookId = $('#comments').attr('bookid');
    //         var startnum = $('#comments').attr('comment-num');
    //         var url = '/m/mazi/comment/' + bookId + "/" + startnum;
    //         $.ajax({
    //             url: url,
    //             type: 'get',
    //             dataType: 'json',
    //             success: function (data, status) {
    //                 if (data.length == 0) {
    //                     //锁住下拉刷新
    //                     me.lock();
    //                     me.noData();
    //                 } else {
    //                     var html = insertToHtml(data);
    //                     $('#comments').append(html);
    //                     var commentNum = $('#comments').attr('comment-num');
    //                     $('#comments').attr('comment-num', data.length + parseInt(commentNum));
    //                 }
    //                 me.resetload();
    //             }
    //         });
    //     }
    // });
});

/**
 * 提交评论界面
 * @param id
 */
function redirectSubmitPage(id, topTarget) {
    $('#comments').attr('commentId', id);
    $('#comments').attr('topTarget', topTarget);
    $('#commentModal').modal('show');
}
function redirectSubmitPage2(id, topTarget, that) {
    $('#comments').attr('commentId', id);
    $('#comments').attr('topTarget', topTarget);
    var comment = $(that).prev().val();
    var commentId = $('#comments').attr('commentId');
    var length = getWordLength(comment);
    if (length > 500) {
        alert('请不要超过500字哟^_^');
    } else if (comment.length <= 0) {
        alert('评论不能为空哟^_^');
    } else {
        postList(comment, commentId, $(that), 2, id);
    }
}
/**
 * 获取当前评论内容的字数长度
 * @param s
 * @returns {*}
 */
function getWordLength(s) {
    if(!s) return 0;
    var s1 = s.replace(/([^\x00-\xff])/g, ' | ');
    var s2 = s1.replace(/\s+/ig, ' ');
    var s2 = s2.replace(/ +/ig, ' ');
    var s2 = s2.replace(/^ */, '').replace(/ *$/, '');
    var curLength = s2.split(' ').length;
    return curLength;
}

/**
 * 提交评论的方法
 * @param sendData 发送数据
 * @param commentId
 * @param ele
 * @param type 1评论区回复 2 新加评论 空则为旧版逻辑
 */
function postList(sendData, commentId, ele, type, subCommentId) {
    ele.attr('disabled',true);
    var requestUrl = encodeURI(window.location.href);
    var cid = commentId;
    var scid = subCommentId;
    if(isColumn){
        var activityId = $('#comments').attr('activityid');
        var topTarget = $('#comments').attr('toptarget');
        var data = {
            content: sendData,
            topicId: activityId,
            topTarget: topTarget,
            requestUrl: requestUrl
        };
        if (commentId !== 'null') {
            data.replyTo = commentId;
        }
        var url = '/m/mazi/columnTopic/comments';
    }else{
        var bookId = $('#comments').attr('bookId');
        var activityId = $('#comments').attr('activityid');
        var topTarget = $('#comments').attr('toptarget');
        var activityStatus = $('#comments').attr('status');
        try{
            activityStatus = parseInt(activityStatus)
        }catch (error){
            activityStatus = 10
        }
        var data = {
            content: sendData,
            bookId: bookId,
            activityId: activityId,
            topTarget: topTarget,
            requestUrl: requestUrl
        };
        if (commentId !== 'null') {
            data.replyTo = commentId;
        }
        var url = '/m/mazi/discuss';
    }
    $.ajax({
        url: url,
        type: 'POST',
        data: JSON.stringify(data),
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        success: function (data, status) {
            if (data.code == 0) {
                var redirectUrl = window.location.href;
                var p = redirectUrl.indexOf('#writeCommentDiv');
                if(p != -1){
                    redirectUrl = redirectUrl.substring(0,p) + redirectUrl.substring((p+'#writeCommentDiv'.length),redirectUrl.length);
                }
                if (activityStatus < 9){
                    alert('您已成功提交评论！')
                }
                var content = '';
                var headImage = $('.c_mine_head').attr("src");
                var htmlstr = '';
                if(type == 1){
                    content = ele.prev().find('textarea').val();
                    var funStr = 'redirectSubmitPage2("'+data.commentId+'","'+data.commentId+'",this)';
                    htmlstr = "<div class='comment_item'><div class='flex_view item_child'><img class='c_mine_head' src='" + headImage + "'><div class='comment_right border_bottom c_right_padding'><div class='c_name_view'><span class='c_name'>我</span><span class='c_time'>刚刚</span></div><div class='c_text'>" + content + "</div><div class='c_good'><a class='good_box' onclick='praiseComment(this)' href='javascript:void(0)' comment-id = '" + data.commentId + "'><img src='https://images.gitbook.cn/FsHauRmbivKG8rMnG15mQZ-e3L9J' isPraise = 'false'><span>鼓掌</span></a><a class='reply_view' href='javascript:void(0)'><img src='https://images.gitbook.cn/Fri_utJ1tPyU8x3LMH3hVKuXx5Sd'><span class='c_reply_text'>回复</span></a></div><div class='clearfix comment_hidden'><textarea class='c_mine_input block_area' placeholder='说点什么' maxlengt ='500'></textarea><div class='comment_btn' onclick="+funStr+">评论</div></div></div></div></div>"
                    $('.comment_content').prepend(htmlstr);
                    $('.c_mine_input').val('');
                    $('.c_reply_text').text('回复');
                    $(".c_send_btn").removeClass('no_opacity');
                    $('.comment_hidden').hide();
                }else if (type == 2){
                    content = ele.prev().val();
                    var funStr = 'redirectSubmitPage2("'+scid+'","'+cid+'",this)';
                    htmlstr = "<div class='comment_inner_view'><div class='comment_inner_item flex_view'><img class='c_inner_head' src='" + headImage + "'><div class='comment_right border_bottom c_inner_right_padding'><div class='c_inner_name'><span class='c_name'>我</span><span class='c_time'>刚刚</span></div><div class='c_text'>" + content + "</div><div class='c_good'><a class='good_box' onclick='praiseComment(this)' href='javascript:void(0)' comment-id = '" + scid + "'><img src='https://images.gitbook.cn/FsHauRmbivKG8rMnG15mQZ-e3L9J' isPraise = 'false'><span>鼓掌</span></a><a class='reply_view' href='javascript:void(0)'><img src='https://images.gitbook.cn/Fri_utJ1tPyU8x3LMH3hVKuXx5Sd'><span class='c_reply_text'>回复</span></a></div><div class='clearfix comment_hidden'><textarea class='c_mine_input block_area' placeholder='说点什么' maxlength='500'></textarea><div class='comment_btn' onclick="+funStr+">评论</div></div></div></div></div>";
                    ele.parents(".comment_item").find('.item_child').after(htmlstr);
                    $(".c_mine_input").val("");
                    $(".c_reply_text").text("回复");
                    $(".c_send_btn").removeClass("no_opacity");
                    $(".comment_hidden").hide();
                }else{
                    window.location.href = redirectUrl + "#writeCommentDiv";
                    location.reload();
                }
            } else {
                alert('回复失败！请稍后再试 ：）');
                $('#submitBtn').html('提交');
                $('#submitBtn').attr('disabled', false);
            }
            ele.attr('disabled', false);
        }
    });
}

/**
 * 点赞触发的时间
 * @param that
 */
function praiseComment(that) {
    var count = parseInt($(that).attr('count'));
    if(count > 1){
        alert('您的操作过于频繁，请刷新后重试');
    }else{
        $(that).attr('count',count+1);
        var imgNode = $(that).find('img');
        var isPraise = imgNode.attr('ispraise');
        var commentId = $(that).attr('comment-id');
        var type;
        if (isPraise === 'false') {
            //点赞
            type = 'post';
        } else {
            //取消点赞
            type = 'delete';
        }
        var url = '/m/mazi/discuss/' + commentId + '/Fav';
        $.ajax({
            url: url,
            type: type,
            contentType: 'application/json; charset=utf-8',
            data: JSON.stringify({
                commentId: commentId
            }),
            dataType: 'json',
            success: function (data) {
                if (data.code === 0 && type === 'post') {
                    //点赞后
                    imgNode.attr('ispraise', true);
                    imgNode.attr('src', 'https://images.gitbook.cn/FuxOLjaxPiey9GeuXVCIBQSnlWjf');
                    var num = parseInt(imgNode.next().html());
                    imgNode.next().html(num ? num + 1 : 1);
                }
                if (data.code == 0 && type == 'delete') {
                    //取消点赞后
                    imgNode.attr('ispraise', false);
                    imgNode.attr('src', 'https://images.gitbook.cn/FsHauRmbivKG8rMnG15mQZ-e3L9J');
                    var num = parseInt(imgNode.next().html());
                    imgNode.next().html(num > 1 ? num - 1 : '鼓掌');
                }
            }
        });
    }
}
/**
 * 将返回的加载评论数据转化成Html
 */

function insertToHtml(data) {
    var html = '';
    data.forEach(function (commentObject) {
        if(commentObject.status ==0) {
            html += parseObjectToHtml(commentObject);
        }
    });
    return html;
}

/**
 * 将Object类型的Comment转化成Html
 */
function parseObjectToHtml(comment) {
    if (!comment)
        return ;
    var html = '';
    var name = comment.nickName;
    if (comment.isAuthor) {
        name += '（作者）'
    }
    var funStr = 'redirectSubmitPage2("' + comment.commentId + '","' + comment.commentId + '",this)';
    if (!comment.isLiked){
        var likeImg = "<img src='https://images.gitbook.cn/FsHauRmbivKG8rMnG15mQZ-e3L9J' isPraise='false'>"
    }else{
        var likeImg = "<img src='https://images.gitbook.cn/FuxOLjaxPiey9GeuXVCIBQSnlWjf' isPraise='true'>"
    }
    if(comment.status === 1){
        html += "<div class='comment_item'>"+
                    "<div class='flex_view item_child'>"+
                        "<img class='c_mine_head' src='"+comment.userAvatar+"'>"+
                        "<div class='comment_right border_bottom c_right_padding'>"+
                            "<div class='c_name_view'>"+
                                "<span class='c_name'>"+name+"</span>"+
                                "<span class='c_time'>" + comment.createdAtStr + "</span>"
                            "</div>"+
                            "<div class='c_text'>" + decodeURIComponent(comment.content) + "</div>" +
                            "<div class='c_good'>"+
                                "<a class='good_box' href='javascript:void(0)' onclick='praiseComment(this)' comment-id = '"+comment._id+"'>"+likeImg+
                                    "<span>" + comment.like.length || '鼓掌' + "</span>"
                                "</a>" +
                                "<a class='reply_view' href='javascript:void(0)'>" +
                                    "<img src='https://images.gitbook.cn/Fri_utJ1tPyU8x3LMH3hVKuXx5Sd'>"+
                                    "<span class='c_reply_text'>回复</span>"
                                "</a>" +
                            "</div>"+
                            "<div class='clearfix comment_hidden'>"+
                                "<textarea class='c_mine_input block_area' placeholder='说点什么' maxlength='500'></textarea>" + 
                                "<div class='comment_btn' onclick=" + funStr + ">评论</div>" +
                            "</div>" + parseSubToHtml(comment.replys, comment.commentId) +
                        "</div>"
                    "</div>"
                "</div>"
    }
    return html;
}
// 子评论
function parseSubToHtml(subcomment, commentId) {
    if(!subcomment || subcomment.length == 0){
        return '';
    }else{
        var name = subcomment.nickName;
        var replyName = subcomment.replyToUser.nickName;
        var replyStr = '';
        if (subcomment.isAuthor) {
            name += '（作者）'
        }
        if (subcomment.replyToUser.isAuthor) {
            replyName += '（作者）'
        }
        if (subcomment.replyToUser) {
            replyStr = "<span class='margin_8'>回复</span><span class='c_name'>" + replyName + "</span>"
        }
        var funStr = 'redirectSubmitPage2("' + subcomment.commentId + '","' + commentId + '",this)';
        if (!subcomment.isLiked) {
            var likeImg = "<img src='https://images.gitbook.cn/FsHauRmbivKG8rMnG15mQZ-e3L9J' isPraise='false'>"
        }else{
            var likeImg = "<img src='https://images.gitbook.cn/FuxOLjaxPiey9GeuXVCIBQSnlWjf' isPraise='true'>"
        }
        if (subcomment.status === 1) {
            html += "<div class='comment_inner_view'>" +
                        "<div class='flex_view comment_inner_item'>" +
                            "<img class='c_inner_head' src='" + subcomment.userAvatar + "'>" +
                            "<div class='comment_right border_bottom c_inner_right_padding'>" +
                                "<div class='c_inner_name'>" +
                                    "<span class='c_name'>" + name + "</span>" + replyStr +
                                    "<span class='c_time'>" + subcomment.createdAtStr + "</span>"
                                "</div>"+
                                "<div class='c_text'>" + decodeURIComponent(subcomment.content) + "</div>" +
                                "<div class='c_good'>"+
                                    "<a class='good_box' href='javascript:void(0)' onclick='praiseComment(this)' comment-id = '" + subcomment._id + "'>" + likeImg +
                                        "<span>" + subcomment.like.length || '鼓掌' + "</span>"
                                    "</a>" +
                                    "<a class='reply_view' href='javascript:void(0)'>" +
                                        "<img src='https://images.gitbook.cn/Fri_utJ1tPyU8x3LMH3hVKuXx5Sd'>"+
                                        "<span class='c_reply_text'>回复</span>"
                                    "</a>" +
                                "</div>"+
                                "<div class='clearfix comment_hidden'>"+
                                    "<textarea class='c_mine_input block_area' placeholder='说点什么' maxlength='500'></textarea>" + 
                                    "<div class='comment_btn' onclick=" + funStr + ">评论</div>" +
                                "</div>" + 
                            "</div>"
                        "</div>"
                    "</div>"
        }
        return html;
    }
}
/**
 * 将子评论数组转化成相应的HTML
 */
function parseSubObjectToHtml(subCommentArray){
    var html ='';
    subCommentArray.forEach(function (subComment) {
        if(subComment.status == 0) {
            html +=
                "<div class='comment-comment'>" +
                    "<span class='sub-comment-name'>" + subComment.customerId.customerName + "</span>" +
                    "<span class='sub-comment-desc'>:" + decodeURIComponent(subComment.content) + "</span>"+
                "</div>"
        }
    });
    console.log(html);
    return html;
}

/**
 * 将对象转化成点赞显示的html
 */
function parsePraiseObject(commentObject) {
    var html ='';
    if(!commentObject.isPraise){
        html += "<div class='comment-unpraise' ispraise='false' comment-id='"+commentObject._id+"' onclick='praiseComment(this)' ></div>";
    }else{
        html += "<div class='comment-praise' ispraise='true' comment-id='"+commentObject._id+"' onclick='praiseComment(this)' ></div>";
    }
    return html;
}

function removeURLParameter(url, parameter) {
    //prefer to use l.search if you have a location/link object
    var urlparts= url.split('?');
    if (urlparts.length>=2) {

        var prefix= encodeURIComponent(parameter)+'=';
        var pars= urlparts[1].split(/[&;]/g);

        //reverse iteration as may be destructive
        for (var i= pars.length; i-- > 0;) {
            //idiom for string.startsWith
            if (pars[i].lastIndexOf(prefix, 0) !== -1) {
                pars.splice(i, 1);
            }
        }

        url= urlparts[0] + (pars.length > 0 ? '?' + pars.join('&') : "");
        return url;
    } else {
        return url;
    }
}

